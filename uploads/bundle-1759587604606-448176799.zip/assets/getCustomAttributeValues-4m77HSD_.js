import{x as r,bF as t,y as s}from"./index-CgP_i9Mc.js";async function i(a){return(await r.get(t.modelName,()=>s(t))).filter(e=>e.attribute_id==a)}export{i as g};
