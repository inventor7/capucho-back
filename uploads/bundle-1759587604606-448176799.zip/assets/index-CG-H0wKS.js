import{aM as i}from"./index-CgP_i9Mc.js";const s=i("PushNotifications",{});export{s as P};
