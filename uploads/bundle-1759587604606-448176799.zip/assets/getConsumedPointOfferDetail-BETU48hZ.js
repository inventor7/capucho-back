import{g as n}from"./getEntityList-efnACquw.js";import{eZ as a}from"./index-CgP_i9Mc.js";async function r(t){return(await n(a)).find(i=>i.consomation_point_ids.includes(t._ruid))}export{r as g};
