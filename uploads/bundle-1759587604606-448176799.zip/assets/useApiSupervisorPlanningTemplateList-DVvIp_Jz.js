import{a as i}from"./useClientApi-CX10GTt5.js";function e(){return i("/api/supervisor/planning-template",{immediate:!0,initialData:[]})}export{e as u};
