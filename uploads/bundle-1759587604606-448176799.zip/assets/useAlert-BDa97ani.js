import{bf as e}from"./index-CgP_i9Mc.js";function s(){return e()}export{s as u};
