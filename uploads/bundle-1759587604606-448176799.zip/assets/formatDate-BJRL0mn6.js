import{bw as t}from"./index-CgP_i9Mc.js";function a(r){return t(r,"P")}export{a as f};
