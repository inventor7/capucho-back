import{u as i}from"./useClientApi-CX10GTt5.js";function r(){return i("/api/supervisor/user",{immediate:!1,initialData:[]})}export{r as u};
