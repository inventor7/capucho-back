import{x as r,d8 as e,y as n}from"./index-CgP_i9Mc.js";async function c(t){return(await r.get(e.modelName,()=>n(e))).filter(a=>a.current_partner_id===t)}export{c as g};
