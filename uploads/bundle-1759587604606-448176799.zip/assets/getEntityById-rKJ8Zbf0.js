import{cM as a}from"./index-CgP_i9Mc.js";async function n(e,t){if(t)return a(e.modelName).get({_ruid:t})}export{n as g};
