import{u as i}from"./useClientApi-CX10GTt5.js";function e(t){return i(`/api/loyalty/${t}/point/history`,{immediate:!0})}export{e as u};
