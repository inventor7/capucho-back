import{bK as n,bN as s,bL as o}from"./index-CgP_i9Mc.js";function i(e,r){n(2,arguments);var a=s(e),t=o(r);return isNaN(t)?new Date(NaN):(t&&a.setDate(a.getDate()+t),a)}export{i as a};
