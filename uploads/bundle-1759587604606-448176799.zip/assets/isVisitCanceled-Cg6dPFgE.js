import{x as t,cZ as a,y as s}from"./index-CgP_i9Mc.js";async function l(i){return(await t.get(a.modelName,()=>s(a))).find(e=>e.visit_id===i._ruid)}export{l as i};
