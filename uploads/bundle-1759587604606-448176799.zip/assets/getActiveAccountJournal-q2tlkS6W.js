import{x as c,bb as a,y as o}from"./index-CgP_i9Mc.js";async function s(e){return(await c.get(a.modelName,()=>o(a))).filter(t=>t.warehouse_id==e)}export{s as g};
