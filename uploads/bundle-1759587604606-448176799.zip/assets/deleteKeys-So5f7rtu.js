import{l as r}from"./index-CgP_i9Mc.js";function d(e){r.forOwn(e,(s,o)=>delete e[o])}export{d};
