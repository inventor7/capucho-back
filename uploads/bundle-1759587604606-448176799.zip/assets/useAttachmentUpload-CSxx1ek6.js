import{b as a}from"./useClientApi-CX10GTt5.js";function o(){const t=a();return{...t,execute:e=>t.execute("/api/attachment",{...e,method:"POST"})}}export{o as u};
