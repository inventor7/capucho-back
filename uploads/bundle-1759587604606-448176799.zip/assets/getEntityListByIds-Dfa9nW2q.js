import{x as s,y as i}from"./index-CgP_i9Mc.js";async function n(t,a){return(await s.get(t.modelName,()=>i(t))).filter(e=>a.includes(e._ruid))}export{n as g};
