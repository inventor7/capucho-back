var s=6e4,n=36e5,a=1e3;export{n as a,a as b,s as m};
