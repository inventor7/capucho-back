import{g as n}from"./getCurrentPlanning-CXwUM7c0.js";import{a$ as r}from"./index-CgP_i9Mc.js";function o(){return r(()=>n())}export{o as u};
