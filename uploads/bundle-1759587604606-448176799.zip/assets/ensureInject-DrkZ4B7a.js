import{a6 as n}from"./index-CgP_i9Mc.js";function a(t){const e=n(t);if(!e)throw new Error(`Unavailable inject state "${t.toString()}"`);return e}export{a as e};
