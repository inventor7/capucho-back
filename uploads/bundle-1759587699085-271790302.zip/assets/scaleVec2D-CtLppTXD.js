function t([n,r],e){return[n*e,r*e]}export{t as s};
