import{u}from"./useClientApi-CX10GTt5.js";function n(t={}){const e=u("/api/logout",{},t);return{...e,execute:o=>e.execute({method:"POST",data:{params:{Token:o}}})}}export{n as u};
