const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-QVJXE54N.js","assets/index-CgP_i9Mc.js"])))=>i.map(i=>d[i]);
import{aM as e,aN as t}from"./index-CgP_i9Mc.js";const i=e("Geolocation",{web:()=>t(()=>import("./web-QVJXE54N.js"),__vite__mapDeps([0,1])).then(o=>new o.GeolocationWeb)});export{i as G};
