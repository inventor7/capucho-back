function t(r,e){const o=r.workflow_id.workflow_type;return o?e.includes(o):!1}export{t as i};
