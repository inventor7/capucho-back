import{a$ as r,A as e}from"./index-CgP_i9Mc.js";function u(){return r(()=>e.getCurrentUser())}export{u};
