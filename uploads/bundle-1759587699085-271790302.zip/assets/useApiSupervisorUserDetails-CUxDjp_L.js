import{u as r}from"./useClientApi-CX10GTt5.js";function s(e){return r(`/api/supervisor/user/${e}`,{immediate:!0})}export{s as u};
