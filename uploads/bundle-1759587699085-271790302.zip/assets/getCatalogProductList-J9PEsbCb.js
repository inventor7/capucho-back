import{x as t,b7 as a,y as e}from"./index-CgP_i9Mc.js";async function c(){return await t.get(a.modelName,()=>e(a))}export{c as g};
