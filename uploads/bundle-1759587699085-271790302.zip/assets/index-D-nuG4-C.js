const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CPtlVlrw.js","assets/index-CgP_i9Mc.js"])))=>i.map(i=>d[i]);
import{aM as e,aN as o}from"./index-CgP_i9Mc.js";const t=e("Browser",{web:()=>o(()=>import("./web-CPtlVlrw.js"),__vite__mapDeps([0,1])).then(r=>new r.BrowserWeb)});export{t as B};
