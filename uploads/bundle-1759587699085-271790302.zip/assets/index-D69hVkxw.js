const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CtORif68.js","assets/index-CgP_i9Mc.js"])))=>i.map(i=>d[i]);
import{aM as e,aN as o}from"./index-CgP_i9Mc.js";const r=e("Toast",{web:()=>o(()=>import("./web-CtORif68.js"),__vite__mapDeps([0,1])).then(t=>new t.ToastWeb)});export{r as T};
