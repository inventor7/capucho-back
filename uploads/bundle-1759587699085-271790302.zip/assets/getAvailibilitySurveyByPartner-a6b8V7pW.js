import{x as i,c5 as a,y as r}from"./index-CgP_i9Mc.js";async function s(e){return(await i.get(a.modelName,()=>r(a))).filter(t=>t.partner_id===e)}export{s as g};
