import{bK as a,bN as s}from"./index-CgP_i9Mc.js";function o(t){a(1,arguments);var r=s(t);return r.setHours(0,0,0,0),r}export{o as s};
