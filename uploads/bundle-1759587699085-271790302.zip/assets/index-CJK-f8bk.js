import{bK as r,bN as t}from"./index-CgP_i9Mc.js";function i(e){return r(1,arguments),t(e).getTime()>Date.now()}export{i};
