import{x as e,cM as t}from"./index-CgP_i9Mc.js";async function i(a){return await e.get(a.modelName,()=>t(a.modelName))}export{i as g};
