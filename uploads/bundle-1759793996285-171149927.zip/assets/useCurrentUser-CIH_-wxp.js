import{b3 as r,A as e}from"./index-DXJaiwBd.js";function u(){return r(()=>e.getCurrentUser())}export{u};
