import{aN as i}from"./index-DXJaiwBd.js";const s=i("PushNotifications",{});export{s as P};
