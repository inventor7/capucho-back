import{a7 as n}from"./index-DXJaiwBd.js";function a(t){const e=n(t);if(!e)throw new Error(`Unavailable inject state "${t.toString()}"`);return e}export{a as e};
