import{bL as r,bM as t}from"./index-DXJaiwBd.js";function i(e){return r(1,arguments),t(e).getTime()>Date.now()}export{i};
