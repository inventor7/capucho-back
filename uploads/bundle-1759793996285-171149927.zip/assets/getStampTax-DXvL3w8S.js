import{x as e,be as a,y as s}from"./index-DXJaiwBd.js";async function o(){return(await e.get(a.modelName,()=>s(a))).find(t=>t.is_stamp_tax)}export{o as g};
