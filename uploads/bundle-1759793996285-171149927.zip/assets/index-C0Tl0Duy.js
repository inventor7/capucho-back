const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BtZs9Y6s.js","assets/index-DXJaiwBd.js"])))=>i.map(i=>d[i]);
import{aN as e,aO as o}from"./index-DXJaiwBd.js";const t=e("Browser",{web:()=>o(()=>import("./web-BtZs9Y6s.js"),__vite__mapDeps([0,1])).then(r=>new r.BrowserWeb)});export{t as B};
