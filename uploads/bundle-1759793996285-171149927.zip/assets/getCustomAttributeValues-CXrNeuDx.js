import{x as r,bG as t,y as s}from"./index-DXJaiwBd.js";async function i(a){return(await r.get(t.modelName,()=>s(t))).filter(e=>e.attribute_id==a)}export{i as g};
