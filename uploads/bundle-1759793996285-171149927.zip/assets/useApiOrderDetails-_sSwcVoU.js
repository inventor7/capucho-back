import{b as i}from"./useClientApi-Cb26T_1N.js";function u(){const e=i();return{...e,execute:(t,s)=>e.execute(`/api/sync/${s}/step2/fetch`,{method:"POST",data:{ruids:[t]}})}}export{u};
