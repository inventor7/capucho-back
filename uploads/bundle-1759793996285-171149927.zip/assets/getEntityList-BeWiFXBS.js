import{x as e,cS as t}from"./index-DXJaiwBd.js";async function i(a){return await e.get(a.modelName,()=>t(a.modelName))}export{i as g};
