import{x as c,bf as a,y as o}from"./index-DXJaiwBd.js";async function s(e){return(await c.get(a.modelName,()=>o(a))).filter(t=>t.warehouse_id==e)}export{s as g};
