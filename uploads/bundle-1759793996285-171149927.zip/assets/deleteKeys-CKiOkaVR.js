import{l as r}from"./index-DXJaiwBd.js";function d(e){r.forOwn(e,(s,o)=>delete e[o])}export{d};
