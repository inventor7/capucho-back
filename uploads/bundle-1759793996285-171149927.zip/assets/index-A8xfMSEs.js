const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-WxE9sWOW.js","assets/index-DXJaiwBd.js"])))=>i.map(i=>d[i]);
import{aN as r,aO as t}from"./index-DXJaiwBd.js";const _=r("Network",{web:()=>t(()=>import("./web-WxE9sWOW.js"),__vite__mapDeps([0,1])).then(e=>new e.NetworkWeb)});export{_ as N};
