import{ad as r,ct as a}from"./index-DXJaiwBd.js";function c(...o){return r(()=>o.some(t=>a(t)))}export{c as l};
