import{f as t}from"./useDateFns-D-y1aXci.js";function o(r){return t(r,"Pp")}export{o as f};
