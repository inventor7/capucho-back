import{x as t,bb as a,y as e}from"./index-DXJaiwBd.js";async function c(){return await t.get(a.modelName,()=>e(a))}export{c as g};
