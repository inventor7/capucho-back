import{x as r,dd as e,y as n}from"./index-DXJaiwBd.js";async function c(t){return(await r.get(e.modelName,()=>n(e))).filter(a=>a.current_partner_id===t)}export{c as g};
