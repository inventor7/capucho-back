import{bj as e}from"./index-DXJaiwBd.js";function s(){return e()}export{s as u};
