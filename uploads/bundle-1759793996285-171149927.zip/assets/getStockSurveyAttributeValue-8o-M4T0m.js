import{x as r,f6 as e,y as n}from"./index-DXJaiwBd.js";async function s(t){return(await r.get(e.modelName,()=>n(e))).find(a=>a._ruid==t)}export{s as g};
