const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-B9tubUC8.js","assets/index-DXJaiwBd.js"])))=>i.map(i=>d[i]);
import{aN as e,aO as t}from"./index-DXJaiwBd.js";const i=e("Geolocation",{web:()=>t(()=>import("./web-B9tubUC8.js"),__vite__mapDeps([0,1])).then(o=>new o.GeolocationWeb)});export{i as G};
