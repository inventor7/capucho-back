const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DMl7X1Dz.js","assets/index-DXJaiwBd.js"])))=>i.map(i=>d[i]);
import{aN as r,aO as p}from"./index-DXJaiwBd.js";const t=r("AppLauncher",{web:()=>p(()=>import("./web-DMl7X1Dz.js"),__vite__mapDeps([0,1])).then(e=>new e.AppLauncherWeb)});export{t as AppLauncher};
