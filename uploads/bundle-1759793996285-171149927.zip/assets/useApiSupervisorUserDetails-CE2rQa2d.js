import{u as r}from"./useClientApi-Cb26T_1N.js";function s(e){return r(`/api/supervisor/user/${e}`,{immediate:!0})}export{s as u};
