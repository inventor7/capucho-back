import{a as i}from"./useClientApi-Cb26T_1N.js";function e(){return i("/api/supervisor/planning-template",{immediate:!0,initialData:[]})}export{e as u};
