import{bs as e,bt as n}from"./index-DXJaiwBd.js";const t=e(()=>({isInZoneEnabled:n("settings-in-zone-enabled",!1)}));export{t as u};
