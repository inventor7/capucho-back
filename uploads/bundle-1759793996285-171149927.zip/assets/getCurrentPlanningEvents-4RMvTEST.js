import{x as s,aP as a,y as r,l}from"./index-DXJaiwBd.js";async function o(e){const n=await s.get(a.modelName,()=>r(a));return l.filter(n,t=>t.planning_id===e._ruid)}export{o as g};
