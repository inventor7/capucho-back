import{f7 as e}from"./index-DXJaiwBd.js";class a extends e{static modelName="survey.no_user_input.reason";static sync={modelName:"survey.no_user_input.reason",fields:[{name:"name"}]}}export{a as S};
