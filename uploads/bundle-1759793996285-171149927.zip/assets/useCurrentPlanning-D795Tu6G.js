import{g as n}from"./getCurrentPlanning-k_XpjxxM.js";import{b3 as r}from"./index-DXJaiwBd.js";function o(){return r(()=>n())}export{o as u};
