import{u as i}from"./useClientApi-Cb26T_1N.js";function e(t){return i(`/api/loyalty/${t}/point/history`,{immediate:!0})}export{e as u};
