import{u as i}from"./useClientApi-Cb26T_1N.js";function r(){return i("/api/supervisor/user",{immediate:!1,initialData:[]})}export{r as u};
