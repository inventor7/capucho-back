import{bL as e,bM as g}from"./index-DXJaiwBd.js";function s(a){e(1,arguments);var r=g(a),t=r.getDay();return t}export{s as g};
