import{bL as t,bM as a}from"./index-DXJaiwBd.js";function o(e){t(1,arguments);var r=a(e);return r.setHours(23,59,59,999),r}export{o as e};
