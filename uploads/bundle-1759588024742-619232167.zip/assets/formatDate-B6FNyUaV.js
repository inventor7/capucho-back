import{bw as t}from"./index-DfRFFmtO.js";function a(r){return t(r,"P")}export{a as f};
