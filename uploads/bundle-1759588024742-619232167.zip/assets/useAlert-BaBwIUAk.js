import{bf as e}from"./index-DfRFFmtO.js";function s(){return e()}export{s as u};
