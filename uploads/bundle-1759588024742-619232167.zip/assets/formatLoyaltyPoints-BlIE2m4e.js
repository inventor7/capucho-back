function r(e){return e%1===0?e.toString():e.toFixed(2).replace(/\.?0+$/,"").replace(".",",")}export{r as f};
