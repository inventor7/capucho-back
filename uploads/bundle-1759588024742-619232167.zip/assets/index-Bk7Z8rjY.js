import{aM as i}from"./index-DfRFFmtO.js";const s=i("PushNotifications",{});export{s as P};
