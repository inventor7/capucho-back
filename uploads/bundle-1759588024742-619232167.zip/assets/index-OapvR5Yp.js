import{bK as r,bN as t}from"./index-DfRFFmtO.js";function i(e){return r(1,arguments),t(e).getTime()>Date.now()}export{i};
