import{g as n}from"./getCurrentPlanning-DC0MLTMr.js";import{a$ as r}from"./index-DfRFFmtO.js";function o(){return r(()=>n())}export{o as u};
