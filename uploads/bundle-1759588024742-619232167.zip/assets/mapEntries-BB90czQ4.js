import{m as s}from"./mapAsync-DslBBHTE.js";async function e(t,n){const r=await s(t,n);return Object.fromEntries(r)}export{e as m};
