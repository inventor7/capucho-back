function l(t){const e=t.target?.select;e&&e.call(t.target)}export{l as i};
