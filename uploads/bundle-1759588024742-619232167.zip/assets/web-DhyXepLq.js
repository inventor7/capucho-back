import{bR as e}from"./index-DfRFFmtO.js";class a extends e{async isLocationEnabled(){return console.log("Checking location enabled status..."),{isEnabled:!1}}}export{a as LocationPluginWeb};
