import{bw as t}from"./index-DfRFFmtO.js";function a(r){return t(r,"Pp")}export{a as f};
