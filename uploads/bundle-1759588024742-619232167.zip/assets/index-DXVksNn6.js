const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-B7BGXJpg.js","assets/index-DfRFFmtO.js"])))=>i.map(i=>d[i]);
import{aM as e,aN as t}from"./index-DfRFFmtO.js";const i=e("Geolocation",{web:()=>t(()=>import("./web-B7BGXJpg.js"),__vite__mapDeps([0,1])).then(o=>new o.GeolocationWeb)});export{i as G};
