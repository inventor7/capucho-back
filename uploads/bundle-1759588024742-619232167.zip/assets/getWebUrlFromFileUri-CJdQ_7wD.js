function e(r){return r||""}export{e as g};
