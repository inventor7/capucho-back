import{a6 as n}from"./index-DfRFFmtO.js";function a(t){const e=n(t);if(!e)throw new Error(`Unavailable inject state "${t.toString()}"`);return e}export{a as e};
