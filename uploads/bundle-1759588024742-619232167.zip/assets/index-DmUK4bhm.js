const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-C5PlJUjQ.js","assets/index-DfRFFmtO.js"])))=>i.map(i=>d[i]);
import{aM as e,aN as o}from"./index-DfRFFmtO.js";const r=e("Toast",{web:()=>o(()=>import("./web-C5PlJUjQ.js"),__vite__mapDeps([0,1])).then(t=>new t.ToastWeb)});export{r as T};
