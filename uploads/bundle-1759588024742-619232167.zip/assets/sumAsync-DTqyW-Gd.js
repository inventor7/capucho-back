import{l as a}from"./index-DfRFFmtO.js";async function r(s){return a.sum(await Promise.all(s))}export{r as s};
