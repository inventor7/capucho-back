import{u as r}from"./useClientApi-DlYu0i1e.js";function s(e){return r(`/api/supervisor/user/${e}`,{immediate:!0})}export{s as u};
