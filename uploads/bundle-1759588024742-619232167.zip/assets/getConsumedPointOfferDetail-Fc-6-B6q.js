import{g as n}from"./getEntityList-DVPb3Vy5.js";import{eZ as a}from"./index-DfRFFmtO.js";async function r(t){return(await n(a)).find(i=>i.consomation_point_ids.includes(t._ruid))}export{r as g};
