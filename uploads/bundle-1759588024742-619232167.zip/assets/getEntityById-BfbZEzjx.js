import{cM as a}from"./index-DfRFFmtO.js";async function n(e,t){if(t)return a(e.modelName).get({_ruid:t})}export{n as g};
