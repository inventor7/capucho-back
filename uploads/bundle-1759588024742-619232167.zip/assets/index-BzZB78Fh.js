const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CDQepseC.js","assets/index-DfRFFmtO.js"])))=>i.map(i=>d[i]);
import{aM as e,aN as o}from"./index-DfRFFmtO.js";const t=e("Browser",{web:()=>o(()=>import("./web-CDQepseC.js"),__vite__mapDeps([0,1])).then(r=>new r.BrowserWeb)});export{t as B};
