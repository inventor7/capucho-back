import{x as t,b7 as a,y as e}from"./index-DfRFFmtO.js";async function c(){return await t.get(a.modelName,()=>e(a))}export{c as g};
