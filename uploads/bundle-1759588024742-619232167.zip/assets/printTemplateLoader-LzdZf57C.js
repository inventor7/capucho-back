import{x as t,eA as a,y as i,l as s}from"./index-DfRFFmtO.js";async function o(n){return(await t.get(a.modelName,()=>i(a))).filter(r=>r.usage==n)}const c=`{{company.name}}\r
\r
UTILISATEUR :  {{user.name}}\r
TOURNÉE     :  {{planning.name}}\r
ENTREPÔT    :  {{warehouse.name}}\r
DATE        :  {{now}}\r
\r
\r
\r
{{!-- Header with fixed column width --}}\r
{{p 22 'QUANTITY'}}|{{p 8 'Total'}}|{{p 8 'Poids'}}\r
--------------------------------------\r
{{!-- Loop over the order lines --}}\r
{{#each order.lines}} \r
{{name}}\r
{{p 22 qty}}|{{p 8 total}}|{{p 8 (fc poids)}}\r
{{/each}}\r
\r
{{!-- Total values --}}\r
Total TTC     : {{fcs order.totalTtc}}\r
Total Poids   : {{fcs order.totalPoids}}\r
---------------------------\r
\r
`,p=`{{company.name}}\r
\r
USER        : {{user.name}}\r
PLANNING    : {{planning.name}}\r
WAREHOUSE   : {{warehouse.name}}\r
DATE        : {{now}}\r
\r
{{#each activities}}\r
{{pe 15 'Date'}}: {{fdt date}}\r
{{pe 15 'Type'}}: {{t 'history.items.typeValues' type}}\r
{{pe 15 'Ref'}}: {{reference}}\r
{{pe 15 'Customer'}}: {{partner.name}}\r
{{#each details}}\r
{{pe 15 (t 'history.items' key)}}: {{value}}\r
{{/each}}\r
---\r
{{/each}}\r
`,d=`{{company.name}}\r
\r
USER        : {{user.name}}\r
{{#if isNotSupervisor}}PLANNING    : {{planning.name}}{{else}}WORKFLOW    : {{workflow}}{{/if}}\r
WAREHOUSE   : {{warehouse.name}}\r
DATE        : {{now}}\r
{{#if isMarch }}\r
\r
Visits\r
---------------------------------------\r
{{#each stats.visits}}\r
{{pe 18 label}}: {{ p 5 value}}\r
{{/each}}\r
\r
{{else if isSupervisor}}\r
\r
Visits\r
---------------------------------------\r
Avec livraison     : {{visits.sucessVisits}}\r
Pas de livraison   : {{visits.failsVisits}}\r
Pas de visite      : {{visits.noVisits}}\r
Reste              : {{visits.remains}}\r
\r
Facturation\r
---------------------------------------\r
Chiffre d'affaires : {{fcs sales.turnover}}\r
Encaissements      : {{fcs paiment.totalPayment}}\r
Factures           : {{sales.totalSales}}\r
Remboursement      : {{fcs paiment.totalOutboundPaiment}}\r
\r
Ventes\r
---------------------------------------\r
Unités             : {{sales.totalQtyUom}}\r
Volume             : {{sales.volume}}\r
poids              : {{fc sales.weight}}\r
PACK               : {{sales.pack}}\r
CAR                : {{sales.car}}\r
\r
Retour\r
---------------------------------------\r
Unités             : {{returns.totalQtyuomReturns}}\r
Volume             : {{fc returns.totalWeightReturn}}\r
poids              : {{returns.totalVolumeReturn}}\r
{{else}}\r
\r
Facturation\r
\r
{{#if invoicesConsolidationData}}\r
{{p 19 'Code Fac'}}|{{p 10 'Montant'}}|{{p 8 'Cluster'}}|{{p 8 'Heure'}}\r
{{p 19 ''}}|{{p 10 ''}}|{{p 8 'Vol.KG'}}|{{p 6 'Statut'}}\r
{{/if}}\r
------------------------------------------------\r
{{#each invoicesConsolidationData}}\r
{{client}}\r
{{p 19 code}}|{{p 10 (fcs amount)}}|{{#if cluster}}{{p 8 cluster}}{{else}}{{p 8 "/"}}{{/if}}|{{p 8 time}}\r
{{p 19 ''}}|{{p 10 ''}}|{{p 8 (fc weight)}}|{{#if cancel}}{{p 6 "Annulé"}}{{else}}{{p 6 "Validé"}}{{/if}}\r
{{/each}}\r
\r
Montant Total : {{fcs totalAmount}}\r
\r
{{#each stats.payments}}\r
{{pe 14 label}}: {{ p 5 value}}\r
{{/each}}\r
\r
------------------------------------------------\r
Consolidation des Ventes\r
\r
{{#if order.lines}}\r
{{p 25 'QUANTITY'}}|{{p 10 'Total'}}|{{p 10 'Poids'}}\r
{{/if}}\r
------------------------------------------------\r
{{#each order.lines}}\r
{{name}}\r
{{p 25 qty}}|{{p 10 (fcs total)}}|{{p 10 (fc poids)}}\r
{{/each}}\r
\r
{{!-- Total values --}}\r
Total TTC     : {{fcs order.totalTtc}}\r
Total Poids   : {{fcs order.totalPoids}}\r
\r
{{#each stats.qty}}\r
{{pe 14 label}}: {{ p 5 value}}\r
{{/each}}\r
\r
------------------------------------------------\r
Globale Volume\r
CA     : {{fcs totalAmount}}\r
KG     : {{fcs globalVolume}}\r
Caisse : {{totalQuantity}}\r
\r
Drop Size\r
CA     : {{fcs revenueDrop}}\r
KG     : {{fc weightDrop}}\r
Caisse : {{totalQuantityDropSize}}\r
------------------------------------------------\r
Visits\r
{{#each stats.visits}}\r
{{pe 18 label}}: {{ p 5 value}}\r
{{/each}}\r
\r
Univers à Couvrir : {{totalVisits}}\r
Clients Couvert   : {{clientCouvert}}\r
Clients Actives   : {{clientActive}}\r
Taux Couverture   : {{fcs tauxCouverture}}%\r
Taux Succes       : {{fcs tauxSucces}}%\r
1ere Facture      : {{firstDate}}\r
Derniere Facture  : {{lastDate}}\r
Total des ventes  : {{fcs totalVente}}\r
\r
{{/if}}\r
\r
\r
\r
\r
\r
`,l=`{{company.name}}\r
\r
USER        : {{user.name}}\r
PLANNING    : {{planning.name}}\r
WAREHOUSE   : {{warehouse.name}}\r
DATE        : {{now}}\r
\r
Visits\r
---------------------------------------\r
{{#ifEquals workflowType 'delivery'}}\r
Avec livraison     : {{stats.visits.withDelivery}}\r
{{else}}\r
Avec vente         : {{stats.visits.withSale}}\r
{{/ifEquals}}\r
{{#ifEquals workflowType 'delivery'}}  \r
Pas de livraison   : {{stats.visits.noDelivery}}\r
{{else}}\r
Pas de vente       : {{stats.visits.noSale}}\r
{{/ifEquals}}\r
Pas de visite      : {{stats.visits.noVisits}}\r
Reste              : {{stats.visits.remains}}\r
\r
Facturation\r
---------------------------------------\r
Chiffre d'affaires : {{ stats.payments.turnover}}\r
Factures           : {{stats.payments.invoice}}\r
Remboursement      : {{ stats.payments.refund}}\r
Paiements          : {{ stats.payments.payment}}\r
\r
Ventes\r
---------------------------------------\r
{{#each stats.qty}}\r
{{pe 19 label}}: {{value}}\r
{{/each}}\r
\r
Retour\r
---------------------------------------\r
{{#each stats.returns.sumPackagingQty}}\r
{{pe 19 name}}: {{qty}}\r
{{/each}}\r
Unités             : {{stats.returns.sumUomQty}}\r
Volume             : {{ stats.returns.sumProductVolume}}\r
poids              : {{stats.returns.sumProductWeight}}\r
`,T=`{{company.name}}\r
\r
UTILISATEUR :  {{user.name}}\r
TOURNÉE     :  {{planning.name}}\r
ENTREPÔT    :  {{warehouse.name}}\r
DATE        :  {{fdt order.date}}\r
CLIENT      :  {{order.partner.name}}\r
RÉF CLIENT  :  {{order.partner.ref}}\r
RÉF         :  {{order.ref}}\r
{{#if warehouse.phone_number}}\r
NUMERO DE RECLAMATION : {{ warehouse.phone_number }}\r
{{/if}}\r
\r
{{#if campaigns}}\r
---------------------------\r
CAMPAGNES DE FIDÉLISATION\r
{{#each campaigns}}\r
{{campaign.name}}\r
    DESC: {{campaign.description}}\r
\r
    {{#each conditionsPoints}}\r
{{condition.name}} - {{condition.type}}\r
        DESC            : {{condition.description}}\r
        INVOICE POINTS  : {{pointValue}}\r
        CURRENT POINTS  : {{currentPoints}}\r
\r
    {{/each}}\r
{{/each}}\r
---------------------------\r
{{/if}}\r
\r
{{p (dynamicPadding isOrderHasDiscount 'HT') 'PU'}}|{{p (dynamicPadding isOrderHasDiscount 'HT') 'QTY'}}|{{p (dynamicPadding isOrderHasDiscount 'HT') 'UDM'}}|{{p (dynamicPadding isOrderHasDiscount 'HT') 'NB'}}|{{p (dynamicPadding isOrderHasDiscount 'HT') 'TTC'}}\r
---------------------------\r
{{#each order.lines}}\r
{{inc @index}}> {{product.name}}\r
{{p (dynamicPadding ../isOrderHasDiscount 'HT') (fc price_unit)}}|{{p (dynamicPadding ../isOrderHasDiscount 'HT') qty}}|{{p (dynamicPadding ../isOrderHasDiscount 'HT') packaging}}|{{p (dynamicPadding ../isOrderHasDiscount 'HT') pack_Qty}}|{{p (dynamicPadding ../isOrderHasDiscount 'HT') (fc price_total)}}{{#if discount}}(-{{discount}}){{/if}}\r
{{/each}}\r
\r
\r
Remise HT   : {{fcs order.total_discount}}\r
Total TTC   : {{fcs order.total_ttc}}\r
Paiement    : {{fcs order.total_payment}}\r
\r
Total de produits  : {{totalProduct}}\r
Nombre de ligne    : {{order.lines.length}}\r
Total des Caisses  : {{total_Caise}}\r
Merci pour votre achat!\r
`,u=`UTILISATEUR :  {{user.name}}\r
TOURNÉE     :  {{planning.name}}\r
ENTREPÔT    :  {{warehouse.name}}\r
DATE        :  {{fdt order.date}}\r
CLIENT      :  {{order.partner.name}}\r
RÉF CLIENT :   {{order.partner.ref}}\r
RÉF         :  {{order.ref}}\r
\r
{{p 8 'PU'}}|{{p 8  'Qty Sel.'}}|{{p 8 'UDM'}}|{{p 8 'TTC'}}\r
---------------------------\r
{{#each order.lines}}\r
{{#if product.sale_ok}}{{inc @index}}>{{/if}} {{product.name}}\r
{{p 8 (fc price_unit)}}|{{p 8 qty}}|{{p 8 packaging}}|{{p 8 (fc price_total)}} {{#if discount}}(-{{discount}}){{/if}}\r
{{/each}}\r
                                                     \r
Total TTC   : {{fcs order.total_ttc}}\r
Paiement    : {{fcs order.total_payment}}\r
\r
Total de produits: {{totalProduct}}\r
Nombre de ligne  : {{totalLignes}}\r
---------------------------\r
\r
`,m=`{{company.name}}\r
\r
UTILISATEUR :  {{user.name}}\r
TOURNÉE     :  {{planning.name}}\r
ENTREPÔT    :  {{warehouse.name}}\r
DATE        :  {{fdt order.date}}\r
CLIENT      :  {{order.partner.name}}\r
RÉF CLIENT  :  {{order.partner.ref}}\r
RÉF         :  {{order.ref}}\r
{{#if warehouse.phone_number}}\r
NUMERO DE RECLAMATION : {{ warehouse.phone_number }}\r
{{/if}}\r
{{#if campaigns}}\r
---------------------------\r
CAMPAGNES DE FIDÉLISATION\r
{{#each campaigns}}\r
{{campaign.name}}\r
    DESC: {{campaign.description}}\r
\r
    {{#each conditionsPoints}}\r
{{condition.name}} - {{condition.type}}\r
        DESC            : {{condition.description}}\r
        INVOICE POINTS  : {{pointValue}}\r
        CURRENT POINTS  : {{currentPoints}}\r
\r
    {{/each}}\r
{{/each}}\r
--------------------------------------------------------\r
{{/if}}\r
\r
{{p (dynamicPadding isOrderHasDiscount) 'PU'}}|{{p (dynamicPadding isOrderHasDiscount) 'QTY'}}|{{p (dynamicPadding isOrderHasDiscount) 'UDM'}}|{{p (dynamicPadding isOrderHasDiscount) 'NB'}}|{{p (dynamicPadding isOrderHasDiscount) 'TVA'}}|{{p (dynamicPadding isOrderHasDiscount) 'TTC'}}\r
------------------------------------------------\r
{{#each order.lines}}\r
{{inc @index}}> {{product.name}}\r
{{p (dynamicPadding ../isOrderHasDiscount) (fc price_unit)}}|{{p (dynamicPadding ../isOrderHasDiscount) qty}}|{{p (dynamicPadding ../isOrderHasDiscount) packaging}}|{{p (dynamicPadding ../isOrderHasDiscount) pack_Qty}}|{{p (dynamicPadding ../isOrderHasDiscount) tax}}%|{{p (dynamicPadding ../isOrderHasDiscount) (fc price_total)}}{{#if discount}}(-{{discount}}){{/if}}\r
{{/each}}\r
\r
Total HT    : {{fcs order.total_ht}}\r
Remise HT   : {{fcs order.total_discount}}\r
TVA         : {{fcs order.total_tax}}\r
Timbre      : {{fcs order.total_stamp}}\r
Total TTC   : {{fcs order.total_ttc}}\r
Paiement    : {{fcs order.total_payment}}\r
\r
Total de produits  : {{totalProduct}}\r
Nombre de ligne    : {{order.lines.length}}\r
Total des Caisses  : {{total_Caise}}\r
Merci pour votre achat!\r
`,E=`BON DE PRÉPARATION\r
\r
{{company.name}}\r
\r
UTILISATEUR :  {{user.name}}\r
TOURNÉE     :  {{planning.name}}\r
ENTREPÔT    :  {{warehouse.name }}\r
DATE        :  {{fdt date}}\r
CLIENT      :  {{partner.name }}\r
RÉF CLIENT :   {{partner.ref}}\r
RÉF : {{order.ref}}\r
{{#each orders}}\r
\r
RÉF         : {{ref}}\r
\r
{{pe 33 'PRODUIT'}}|{{p 4 'QTY'}}|{{p 8 'UDM'}}\r
-----------------------------------------\r
{{#each lines}}\r
{{#multiLine product.name 33}}\r
{{#if isFirst}}\r
{{pe 33 line}}|{{p 4 ../qty}}|{{p 8 ../packaging}}\r
{{else}}\r
{{pe 33 line}}|{{p 4 ''}}|{{p 8 ''}}\r
{{/if}}\r
{{/multiLine}}\r
{{/each}}\r
\r
-----------------------------------------\r
{{/each}}\r
\r
{{wrapText "Ceci est une préparation de marchandise. Vérifiez attentivement votre marchandise avant validation. Après validation, aucune modification ne sera retenue. Merci." 40}}\r
`,f=`{{company.name}}\r
\r
USER        : {{user.name}}\r
PLANNING    : {{planning.name}}\r
WAREHOUSE   : {{warehouse.name}}\r
DATE        : {{now}}\r
\r
{{#each entries}}\r
\r
> {{product.name}} \r
  {{quantities}} {{#has_promo}} [PROMO]{{/has_promo}}\r
{{/each}}\r
`,A=`{{company.name}}\r
\r
USER        : {{user.name}}\r
PLANNING    : {{planning.name}}\r
WAREHOUSE   : {{warehouse.name}}\r
DATE        : {{now}}\r
\r
INITIAL |INPUT   |OUTPUT  |CURRENT\r
----------------------------------\r
{{#each entries}}\r
> {{product.name}} \r
{{p 8 initial}}|{{p 8 input}}|{{p 8 output}}|{{p 8 current}}\r
{{/each}}\r
`,h=`{{company.name}}\r
\r
USER: {{user.name}}\r
PLANNING: {{planning.name}}\r
WAREHOUSE: {{warehouse.name}}\r
DATE: {{fdt request.date_created}}\r
REF: {{request.name}}\r
\r
{{pe 10 'PU'}}|{{pe 5 'QTY'}}|{{pe 5 'UOM'}}\r
-----------------------------------------------\r
{{#each request.lines}}\r
> {{product}} \r
{{ps 10 (fc price_unit)}}|{{ps 5 qty}}|{{pe 5 unit_type}}\r
{{/each}}\r
\r
Total: {{fc request.total_ht}}\r
`,R=`CLIENT          : {{partner.name}}\r
DATE            : {{now}}\r
CAMPAIGN NAME   : {{campaign.name}}\r
CAMPAIGN DESC   : {{campaign.description}}\r
\r
{{#each entries}}\r
> {{condition.name}} - {{condition.type}}\r
    DESC            : {{condition.description}}\r
    TOTAL POINTS    : {{totalPoints}}\r
    CURRENT POINTS  : {{currentPoints}}\r
    CONSUMED POINTS : {{consumedPoints}}\r
    {{#if nextTarget}}\r
    NEXT OBJECTIVE  : {{nextTarget.qty_point_needed}}\r
    {{/if}}\r
{{quantities}}\r
{{/each}}`,N=`{{company.name}}\r
\r
UTILISATEUR :  {{user.name}}\r
TOURNÉE     :  {{planning.name}}\r
ENTREPÔT    :  {{warehouse.name}}\r
DATE        :  {{fdt control.date}}\r
TYPE        :  {{type}}\r
\r
{{p 9 'TH QTY'}}|{{p 9  'QTY'}}|{{p 9 'UDM'}}\r
---------------------------\r
{{#each control.lines}}\r
{{product.name}}\r
{{#if packaging}}{{p 9 th_pkgQty}}{{else}}{{p 9 th_uomQty}}{{/if}}|{{#if packaging}}{{p 9 pkgQty}}{{else}}{{p 9 uomQty}}{{/if}}|{{#if packaging}}{{p 9 packaging.prefix}}{{else}}{{p 9 "U"}}{{/if}}\r
{{/each}}\r
---------------------------\r
\r
{{#if detailsAmounts}}\r
MONTANT TOTAL VENTES    : {{fcs detailsAmounts.saleAmount}}\r
MONTANT DE L'ÉCART      : {{fcs detailsAmounts.diffAmount}}\r
TOTAL A VERSER          : {{fcs detailsAmounts.paidAmount}}\r
TOTAL DES RETOURS       : {{fcs detailsAmounts.returnAmount}}\r
{{/if}}`,P=`{{company.name}}\r
\r
UTILISATEUR        : {{user.name}}\r
TOURNÉE    : {{planning.name}}\r
ENTREPÔT   : {{warehouse.name}}\r
DATE        : {{now}}\r
\r
CASHING     : {{ fcs data.cashing }}\r
 \r
\r
{{pe 15 'Bill'}} {{pe 15 'QTY'}} {{pe 15 'Montant'}}\r
--------------------------------------\r
{{#each data.cashes}}\r
{{pe 15 name}} {{pe 15 qty}} {{amount}}\r
{{/each}}\r
--------------------------------------\r
Total: {{fcs data.total }}\r
`,y=`{{company.name}}\r
\r
UTILISATEUR :  {{user.name}}\r
TOURNÉE     :  {{planning.name}}\r
ENTREPÔT    :  {{warehouse.name}}\r
DATE        :  {{now}}\r
\r
\r
\r
{{p 19 'Code Fac'}}|{{p 10 'Montant'}}|{{p 8 'Cluster'}}|{{p 8 'Heure'}}\r
{{p 19 ''}}|{{p 10 ''}}|{{p 8 'Vol.KG'}}|{{p 6 'Statut'}}\r
----------------------------------------------\r
{{#each invoicesConsolidationData}}\r
{{client}}\r
{{p 19 code}}|{{p 10 (fc amount)}}|{{#if cluster}}{{p 8 cluster}}{{else}}{{p 8 "/"}}{{/if}}|{{p 8 time}}\r
{{p 19 ''}}|{{p 10 ''}}|{{p 8 (fc weight)}}|{{#if cancel}}{{p 6 "Annulé"}}{{else}}{{p 6 "Validé"}}{{/if}}\r
{{/each}}\r
\r
Montant Total : {{fcs totalAmount}}\r
---------------------------\r
\r
`,g=`{{#ifEquals planning.workflow_id.workflow_type "delivery"}}\r
{\r
  "TOTAL": "{{order.total_ttc}}",\r
  "CLIENT": "{{partner.name}}",\r
  "REF": "{{order.ref}}",\r
  "TOURNEE": "{{planning.name}}",\r
  "DATE": "{{order.date}}"\r
}\r
{{/ifEquals}}\r
\r
{{#ifEquals planning.workflow_id.workflow_type "vansale"}}\r
{\r
  "TOTAL": "{{order.total_ttc}}",\r
  "CLIENT": "{{partner.name}}",\r
  "REF": "{{order.ref}}",\r
  "TOURNEE": "{{planning.name}}",\r
  "DATE": "{{order.date}}"\r
}\r
{{/ifEquals}}\r
`,O=`{{#ifEquals planning.workflow_id.workflow_type "delivery"}}\r
{\r
  "TOTAL": "{{order.total_ht}}",\r
  "CLIENT": "{{partner.name}}",\r
  "REF": "{{order.ref}}",\r
  "TOURNEE": "{{planning.name}}",\r
  "DATE": "{{order.date}}"\r
}\r
{{/ifEquals}}\r
\r
{{#ifEquals planning.workflow_id.workflow_type "vansale"}}\r
{\r
  "TOTAL": "{{order.total_ht}}",\r
  "CLIENT": "{{partner.name}}",\r
  "REF": "{{order.ref}}",\r
  "TOURNEE": "{{planning.name}}",\r
  "DATE": "{{order.date}}"\r
}\r
{{/ifEquals}}\r
`;async function C(n){const e=await o(n),r=s.head(e.reverse());return r?r.template:{consolidation:c,history:p,dashboard:d,dashboard_content:l,order_ht:T,order_ttc:m,delivery_details:E,current_stock:f,stock_log:A,loading_request:h,loyalty_campaign:R,stock_control:N,sondage_user_order:u,cash:P,invoices_consolidation:y,qr_code_ttc:g,qr_code_ht:O}[n]}export{C as p};
