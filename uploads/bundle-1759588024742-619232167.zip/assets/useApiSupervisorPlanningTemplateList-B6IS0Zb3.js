import{a as i}from"./useClientApi-DlYu0i1e.js";function e(){return i("/api/supervisor/planning-template",{immediate:!0,initialData:[]})}export{e as u};
