const o="/promo.png";export{o as _};
