const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DoDwNmXu.js","assets/index-DfRFFmtO.js"])))=>i.map(i=>d[i]);
import{aM as r,aN as t}from"./index-DfRFFmtO.js";const _=r("Network",{web:()=>t(()=>import("./web-DoDwNmXu.js"),__vite__mapDeps([0,1])).then(e=>new e.NetworkWeb)});export{_ as N};
