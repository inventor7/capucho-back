import{u}from"./useClientApi-DlYu0i1e.js";function n(t={}){const e=u("/api/logout",{},t);return{...e,execute:o=>e.execute({method:"POST",data:{params:{Token:o}}})}}export{n as u};
