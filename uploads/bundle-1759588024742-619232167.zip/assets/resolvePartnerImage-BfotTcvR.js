import{g}from"./getWebUrlFromFileUri-CJdQ_7wD.js";function a(e,r="lg"){const t={sm:"/default-user.png",lg:"/default-user.png"};return e?.image_1920?g(e.image_1920):t[r]}export{a as r};
