import{b as a}from"./useClientApi-DlYu0i1e.js";function o(){const t=a();return{...t,execute:e=>t.execute("/api/attachment",{...e,method:"POST"})}}export{o as u};
