import{a$ as r,A as e}from"./index-DfRFFmtO.js";function u(){return r(()=>e.getCurrentUser())}export{u};
