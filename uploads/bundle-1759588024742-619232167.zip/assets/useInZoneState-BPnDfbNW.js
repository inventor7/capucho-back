import{bp as e,bq as n}from"./index-DfRFFmtO.js";const s=e(()=>({isInZoneEnabled:n("settings-in-zone-enabled",!1)}));export{s as u};
