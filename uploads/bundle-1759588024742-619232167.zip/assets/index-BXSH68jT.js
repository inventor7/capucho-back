const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DW0M_VAB.js","assets/index-DfRFFmtO.js"])))=>i.map(i=>d[i]);
import{aM as r,aN as p}from"./index-DfRFFmtO.js";const t=r("AppLauncher",{web:()=>p(()=>import("./web-DW0M_VAB.js"),__vite__mapDeps([0,1])).then(e=>new e.AppLauncherWeb)});export{t as AppLauncher};
