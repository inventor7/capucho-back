import{x as o,bG as e,y as s}from"./index-DfRFFmtO.js";async function l(a){return(await o.get(e.modelName,()=>s(e))).filter(t=>t.model_id===a&&t.display_in_app)}export{l as g};
