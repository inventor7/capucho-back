const o="/logo6.svg";export{o as _};
