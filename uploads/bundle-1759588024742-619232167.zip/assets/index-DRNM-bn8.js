import{bK as e,bN as g}from"./index-DfRFFmtO.js";function s(a){e(1,arguments);var r=g(a),t=r.getDay();return t}export{s as g};
