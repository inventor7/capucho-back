import{u as i}from"./useClientApi-DlYu0i1e.js";function r(){return i("/api/supervisor/user",{immediate:!1,initialData:[]})}export{r as u};
