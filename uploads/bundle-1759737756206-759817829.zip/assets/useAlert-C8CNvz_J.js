import{bf as e}from"./index-DUkd0cqJ.js";function s(){return e()}export{s as u};
