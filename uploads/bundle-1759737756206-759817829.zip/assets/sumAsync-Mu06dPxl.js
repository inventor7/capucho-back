import{l as a}from"./index-DUkd0cqJ.js";async function r(s){return a.sum(await Promise.all(s))}export{r as s};
