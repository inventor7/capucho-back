import{g as n}from"./getCurrentPlanning-D5qs0Wdc.js";import{a$ as r}from"./index-DUkd0cqJ.js";function o(){return r(()=>n())}export{o as u};
