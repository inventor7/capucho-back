import{l as r}from"./index-DUkd0cqJ.js";function d(e){r.forOwn(e,(s,o)=>delete e[o])}export{d};
