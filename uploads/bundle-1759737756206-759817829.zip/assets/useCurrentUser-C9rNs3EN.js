import{a$ as r,A as e}from"./index-DUkd0cqJ.js";function u(){return r(()=>e.getCurrentUser())}export{u};
