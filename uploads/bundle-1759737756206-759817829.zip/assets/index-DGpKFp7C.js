const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BEcXMxEg.js","assets/index-DUkd0cqJ.js"])))=>i.map(i=>d[i]);
import{aM as e,aN as t}from"./index-DUkd0cqJ.js";const i=e("Geolocation",{web:()=>t(()=>import("./web-BEcXMxEg.js"),__vite__mapDeps([0,1])).then(o=>new o.GeolocationWeb)});export{i as G};
