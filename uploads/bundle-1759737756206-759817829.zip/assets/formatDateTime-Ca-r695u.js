import{bw as t}from"./index-DUkd0cqJ.js";function a(r){return t(r,"Pp")}export{a as f};
