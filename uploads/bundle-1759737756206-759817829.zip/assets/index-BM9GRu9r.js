import{ac as t,cm as a}from"./index-DUkd0cqJ.js";function e(...o){return t(()=>o.some(r=>a(r)))}export{e as l};
