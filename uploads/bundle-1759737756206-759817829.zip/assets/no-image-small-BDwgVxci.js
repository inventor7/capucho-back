const o="/no-image-small.png";export{o as _};
