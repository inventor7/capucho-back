const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BGmYkXJh.js","assets/index-DUkd0cqJ.js"])))=>i.map(i=>d[i]);
import{aM as e,aN as o}from"./index-DUkd0cqJ.js";const t=e("Browser",{web:()=>o(()=>import("./web-BGmYkXJh.js"),__vite__mapDeps([0,1])).then(r=>new r.BrowserWeb)});export{t as B};
