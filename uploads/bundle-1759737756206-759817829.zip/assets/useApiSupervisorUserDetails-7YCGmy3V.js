import{u as r}from"./useClientApi-DZESboX7.js";function s(e){return r(`/api/supervisor/user/${e}`,{immediate:!0})}export{s as u};
