const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DxBUk8uN.js","assets/index-DUkd0cqJ.js"])))=>i.map(i=>d[i]);
import{aM as r,aN as p}from"./index-DUkd0cqJ.js";const t=r("AppLauncher",{web:()=>p(()=>import("./web-DxBUk8uN.js"),__vite__mapDeps([0,1])).then(e=>new e.AppLauncherWeb)});export{t as AppLauncher};
