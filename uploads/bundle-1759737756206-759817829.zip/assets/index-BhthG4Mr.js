import{bK as e,bN as r}from"./index-DUkd0cqJ.js";function s(t){return e(1,arguments),r(t).getTime()<Date.now()}export{s as i};
