import{fl as e}from"./index-DUkd0cqJ.js";class a extends e{static modelName="survey.no_user_input.reason";static sync={modelName:"survey.no_user_input.reason",fields:[{name:"name"}]}}export{a as S};
