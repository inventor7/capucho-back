const s="/default-user.png";export{s as _};
