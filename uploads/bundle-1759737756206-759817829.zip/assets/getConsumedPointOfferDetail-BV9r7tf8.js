import{g as n}from"./getEntityList-QJW4GLE_.js";import{eZ as a}from"./index-DUkd0cqJ.js";async function r(t){return(await n(a)).find(i=>i.consomation_point_ids.includes(t._ruid))}export{r as g};
