import{x as r,bF as t,y as s}from"./index-DUkd0cqJ.js";async function i(a){return(await r.get(t.modelName,()=>s(t))).filter(e=>e.attribute_id==a)}export{i as g};
