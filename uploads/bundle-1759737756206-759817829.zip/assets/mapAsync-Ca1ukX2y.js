import{l as t}from"./index-DUkd0cqJ.js";async function e(r,a){const s=t.map(r,o=>a(o));return await Promise.all(s)}export{e as m};
