import{bK as t,bN as a}from"./index-DUkd0cqJ.js";function o(e){t(1,arguments);var r=a(e);return r.setHours(23,59,59,999),r}export{o as e};
