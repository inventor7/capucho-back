import{x as r,b7 as e,y as c}from"./index-DUkd0cqJ.js";async function o(a){return a?(await r.get(e.modelName,()=>c(e))).find(t=>t._ruid===a):null}export{o as g};
