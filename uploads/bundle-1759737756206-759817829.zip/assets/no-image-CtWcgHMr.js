const o="/no-image.png";export{o as _};
