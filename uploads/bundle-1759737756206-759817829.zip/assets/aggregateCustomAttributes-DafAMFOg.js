import{l as t}from"./index-DUkd0cqJ.js";function e(r){return t.compact(t.times(10,s=>t.get(r,`partner_custom_attribute_${s}`)))}export{e as a};
