import{x as c,bb as a,y as o}from"./index-DUkd0cqJ.js";async function s(e){return(await c.get(a.modelName,()=>o(a))).filter(t=>t.warehouse_id==e)}export{s as g};
