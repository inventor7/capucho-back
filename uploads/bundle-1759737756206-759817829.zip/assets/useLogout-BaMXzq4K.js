import{u}from"./useClientApi-DZESboX7.js";function n(t={}){const e=u("/api/logout",{},t);return{...e,execute:o=>e.execute({method:"POST",data:{params:{Token:o}}})}}export{n as u};
