import{a as i}from"./useClientApi-DZESboX7.js";function e(){return i("/api/supervisor/planning-template",{immediate:!0,initialData:[]})}export{e as u};
