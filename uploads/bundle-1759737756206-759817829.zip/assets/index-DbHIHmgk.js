import{aM as i}from"./index-DUkd0cqJ.js";const s=i("PushNotifications",{});export{s as P};
